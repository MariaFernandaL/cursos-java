package co.edu.cue.lab.exception;

public class PasswordException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public PasswordException(String message) {
		super(message);
	}

}
