package co.edu.cue.webapp.drogueria.exceptions;

public class EmpleadoException extends Exception{

    public EmpleadoException(String mensaje) {
        super(mensaje);
    }

}
