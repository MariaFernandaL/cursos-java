package co.edu.cue.webapp.drogueria.exceptions;

public class ProductoException extends Exception{

    public ProductoException(String mensaje) {
        super(mensaje);
    }

}
