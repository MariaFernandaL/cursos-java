package co.edu.cue.webapp.drogueria.exceptions;

public class DomicilioException extends Exception{

    public DomicilioException(String mensaje) {
        super(mensaje);
    }
}
