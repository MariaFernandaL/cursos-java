package com.drogueria.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrogueriaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrogueriaApiApplication.class, args);
	}

}
